from paus import *

app = Paus()
app.interfaceCli()
